# Fundamentos Claves de Socket.IO (Ejemplo con App de Productos en Node.js)

## 1. ¿Qué es Socket.IO?
Socket.IO es una biblioteca que permite comunicación **bidireccional y en tiempo real** entre cliente y servidor.

- **Bidireccional**: El servidor puede enviar datos al cliente y viceversa sin necesidad de que el cliente pregunte constantemente.
- **Tiempo real**: Los datos se envían y reciben tan pronto como ocurren, sin esperar recargas de página.

En esta app lo usamos para **actualizar la lista de productos en vivo** en todas las pestañas abiertas.

---

## 2. Flujo básico en esta app

1. **Conexión del cliente**
   En el navegador (`client.js`):
   ```js
   const socket = io(); // se conecta automáticamente al servidor actual
   ```

2. **Servidor habilitando Socket.IO**
   En `server.js`:
   ```js
   import { createServer } from "node:http";
   import { Server as SocketIOServer } from "socket.io";

   const httpServer = createServer(app);
   const io = new SocketIOServer(httpServer);
   ```

3. **Emisión de eventos desde el servidor**
   Cuando se agrega un producto desde el formulario:
   ```js
   app.post("/api/productos", (req, res) => {
     const nuevo = { nombre, precio: Number(precio) };
     productos.push(nuevo);
     productosForm.push(nuevo);
     io.emit("producto:nuevo", nuevo); // envía a todos los clientes
     res.status(201).json(nuevo);
   });
   ```

4. **Recepción de eventos en el cliente**
   En `client.js`:
   ```js
   socket.on("producto:nuevo", (producto) => {
     // Actualizar la lista en el DOM
   });
   ```

---

## 3. Conceptos clave

### 3.1. Eventos
- **Emitir**: Enviar un mensaje con un nombre y datos.
  ```js
  io.emit("nombreEvento", data); // servidor -> todos
  socket.emit("nombreEvento", data); // servidor -> 1 cliente
  socket.broadcast.emit("nombreEvento", data); // a todos excepto uno
  ```
- **Escuchar**: Responder cuando llegue un evento.
  ```js
  socket.on("nombreEvento", (data) => { ... });
  ```

### 3.2. Canales ("rooms")
Socket.IO permite agrupar sockets en "salas" para enviar mensajes solo a ciertos clientes.
```js
socket.join("sala1");
io.to("sala1").emit("evento", data);
```

### 3.3. Handshake y reconexiones
- El cliente inicia una **negociación** para elegir el mejor transporte (WebSocket o long-polling).
- Socket.IO maneja reconexiones automáticamente si se cae la conexión.

---

## 4. Ventajas frente a otras técnicas
- No hace falta que el cliente pregunte cada X segundos (polling).
- Fácil de integrar con Express.
- API simple y uniforme para cliente y servidor.

---

## 5. Resumen del ciclo en nuestra app

1. El usuario envía el formulario en `/`.
2. Express lo recibe, guarda el producto y lo agrega también a `productosForm`.
3. El servidor emite `producto:nuevo` a todos los sockets conectados.
4. Todos los navegadores abiertos reciben el evento y actualizan su lista sin recargar.

---

## 6. Código simplificado del tiempo real

**Servidor**
```js
io.on("connection", (socket) => {
  console.log("Nuevo cliente conectado");
});

app.post("/api/productos", (req, res) => {
  const nuevo = { nombre, precio: Number(precio) };
  productos.push(nuevo);
  productosForm.push(nuevo);
  io.emit("producto:nuevo", nuevo);
  res.status(201).json(nuevo);
});
```

**Cliente**
```js
const socket = io();

socket.on("producto:nuevo", (producto) => {
  // Actualiza la lista en pantalla
});
```

---

**Conclusión**: Socket.IO nos permite mantener sincronizadas varias vistas en tiempo real, con muy poco código adicional sobre Express.
